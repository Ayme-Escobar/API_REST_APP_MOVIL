<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Autenticacion {
    private static $clave = "";

    public static function inicializar() {
        if (isset($_ENV['JWT_SECRET'])) {
            self::$clave = $_ENV['JWT_SECRET'];
        } else {            
            error_log("Error: JWT_SECRET no está configurado en el archivo .env");
            throw new Exception("Clave JWT_SECRET no configurada.");
        }
    }

    public static function generarToken($datos) {
        try {
            return JWT::encode($datos, self::$clave, 'HS256');
        } catch (Exception $e) {            
            error_log("Error al generar el token: " . $e->getMessage());
            throw new Exception("No se pudo generar el token.");
        }
    }

    public static function verificarToken($token) {
        try {
            return JWT::decode($token, new Key(self::$clave, 'HS256'));
        } catch (\Firebase\JWT\ExpiredException $e) {            
            error_log("Token expirado: " . $e->getMessage());
            return false;
        } catch (\Firebase\JWT\SignatureInvalidException $e) {            
            error_log("Firma inválida en el token: " . $e->getMessage());
            return false;
        } catch (Exception $e) {    
            error_log("Error al verificar el token: " . $e->getMessage());
            return false;
        }
    }
}

Autenticacion::inicializar();
