<?php
include_once __DIR__ . '/../modelo/Usuario.php'; 
include_once __DIR__ . '/../utilidades/auth.php'; 

class ControladorUsuario {    
    public static function registrar($db, $datos) {
        $usuario = new Usuario($db);
        $usuario->nombre = $datos['nombre'];
        $usuario->correo = $datos['correo'];
        $usuario->contrasena = password_hash($datos['contrasena'], PASSWORD_BCRYPT);
    
        try {
            $resultado = $usuario->crear();
            return ["mensaje" => $resultado['mensaje']];
        } catch (Exception $e) {
            return ["error" => $e->getMessage()];
        }
    }
    
    public static function iniciarSesion($db, $datos) {
        $usuario = new Usuario($db);
        $usuario->correo = $datos['correo'];

        $registro = $usuario->buscarPorCorreo();
        if ($registro && password_verify($datos['contrasena'], $registro['contrasena'])) {
            $token = Autenticacion::generarToken([
                "id" => $registro['id'],
                "correo" => $registro['correo']
            ]);

            return ["mensaje" => "Inicio de sesión exitoso.", "token" => $token];
        }

        return ["error" => "Credenciales inválidas."];
    }
    
    public static function obtenerTodosLosUsuarios($db) {
        $usuario = new Usuario($db);
        return $usuario->obtenerTodos();
    }
    
    public static function actualizarUsuario($db, $datos) {
        try {            
            $usuario = new Usuario($db);
            $usuario->id = $datos['id'];
            $usuario->nombre = $datos['nombre'];
            $usuario->correo = $datos['correo'];
            
            if ($usuario->actualizar()) {
                return ["mensaje" => "Usuario actualizado con éxito."];
            } else {
                return ["error" => "No se pudo actualizar el usuario."]; 
            }
        } catch (PDOException $e) {            
            if ($e->getCode() == 23000) {
                return [
                    "error" => "El correo ya está registrado."
                ];
            }
            
            return [
                "error" => "Ocurrió un error al intentar actualizar el usuario.",
                "detalles" => $e->getMessage()
            ];
        } catch (Exception $e) {            
            return [
                "error" => "Ocurrió un error inesperado.",
                "detalles" => $e->getMessage()
            ];
        }
    }
    
    public static function eliminarUsuario($db, $id) {
        $usuario = new Usuario($db);
        $usuario->id = $id;

        if ($usuario->eliminar()) {
            return ["mensaje" => "Usuario eliminado con éxito."];
        }

        return ["error" => "No se pudo eliminar el usuario."];
    }
}
