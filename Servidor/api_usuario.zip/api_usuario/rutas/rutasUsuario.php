<?php
include_once __DIR__ . '/../controlador/ControladorUsuario.php';

class RutasUsuario {
    public static function manejar($db, $accion, $datos = null) {
        switch ($accion) {
            case 'registrar':
                return ControladorUsuario::registrar($db, $datos);
            case 'iniciarSesion':
                return ControladorUsuario::iniciarSesion($db, $datos);
            case 'obtenerTodos':
                return ControladorUsuario::obtenerTodosLosUsuarios($db);
            case 'actualizar':
                return ControladorUsuario::actualizarUsuario($db, $datos);
            case 'eliminar':
                return ControladorUsuario::eliminarUsuario($db, $datos['id']);
            default:
                return ["error" => "Ruta no válida."];
        }
    }
}
