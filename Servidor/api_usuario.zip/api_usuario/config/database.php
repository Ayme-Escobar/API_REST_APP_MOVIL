<?php
class BaseDeDatos {
    private $servidor = "localhost";
    private $puerto = "3307";
    private $nombre_base_datos = "usuario_bdd";
    private $usuario = "root";
    private $contraseña = "";
    public $conexion;

    public function obtenerConexion() {
        $this->conexion = null;
        try {
            $this->conexion = new PDO(
                "mysql:host=" . $this->servidor . ";port=" . $this->puerto . ";dbname=" . $this->nombre_base_datos,
                $this->usuario,
                $this->contraseña
            );
            $this->conexion->exec("set names utf8");
        } catch (PDOException $excepcion) {
            echo "Error de conexión: " . $excepcion->getMessage();
        }
        return $this->conexion;
    }
}
