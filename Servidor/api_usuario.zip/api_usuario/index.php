<?php

require __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

header("Content-Type: application/json");

include_once './config/database.php'; 
$baseDeDatos = new BaseDeDatos();
$db = $baseDeDatos->obtenerConexion(); 

include_once './rutas/rutasUsuario.php';
include_once './utilidades/auth.php';
Autenticacion::inicializar();

$datos = json_decode(file_get_contents("php://input"), true);
$accion = $_GET['accion'] ?? ''; 


$rutasProtegidas = ['actualizar', 'eliminar', 'obtenerTodos'];

if (in_array($accion, $rutasProtegidas)) {
    
    $encabezados = apache_request_headers();
    $encabezadoAutorizacion = $encabezados['Authorization'] ?? $encabezados['authorization'] ?? null;

    if (!$encabezadoAutorizacion) {
        echo json_encode([
            "error" => "Token no proporcionado.",
            "metodo" => $_SERVER['REQUEST_METHOD'],
            "ruta" => $accion,
        ]);
        exit;
    }

    
    $token = str_replace('Bearer ', '', $encabezadoAutorizacion);
    $decodificado = Autenticacion::verificarToken($token);

    if (!$decodificado) {
        echo json_encode(["error" => "Token inválido o expirado."]);
        exit;
    }

    
    $datos['id_usuario'] = $decodificado->id;
}

echo json_encode(RutasUsuario::manejar($db, $accion, $datos));
