<?php
class Usuario {
    private $conexion; 
    private $tabla = "usuarios"; 

    // Propiedades
    public $id;
    public $nombre;
    public $correo;
    public $contrasena;
    public $fecha_creacion;
    
    public function __construct($db) {
        $this->conexion = $db;
    }
    
    public function crear() {        
        $consultaVerificar = "SELECT id FROM " . $this->tabla . " WHERE correo = :correo";
        $stmtVerificar = $this->conexion->prepare($consultaVerificar);
        $stmtVerificar->bindParam(':correo', $this->correo);
        $stmtVerificar->execute();
    
        if ($stmtVerificar->rowCount() > 0) {            
            throw new Exception("El correo ya está registrado.");
        }
            
        $consulta = "INSERT INTO " . $this->tabla . " (nombre, correo, contrasena) VALUES (:nombre, :correo, :contrasena)";
        $stmt = $this->conexion->prepare($consulta);
    
        $stmt->bindParam(':nombre', $this->nombre);
        $stmt->bindParam(':correo', $this->correo);
        $stmt->bindParam(':contrasena', $this->contrasena);
    
        if ($stmt->execute()) {
            return ["mensaje" => "Usuario creado con éxito"];
        } else {
            throw new Exception("Error al crear el usuario.");
        }
    }
    
    public function buscarPorCorreo() {
        $consulta = "SELECT * FROM " . $this->tabla . " WHERE correo = :correo";
        $stmt = $this->conexion->prepare($consulta);

        $stmt->bindParam(':correo', $this->correo);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC); 
    }

    public function obtenerTodos() {
        $consulta = "SELECT id, nombre, correo, fecha_creacion FROM " . $this->tabla;
        $stmt = $this->conexion->prepare($consulta);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC); 
    }

    
    public function actualizar() {
        $consulta = "UPDATE " . $this->tabla . " SET nombre = :nombre, correo = :correo WHERE id = :id";
        $stmt = $this->conexion->prepare($consulta);

        $stmt->bindParam(':nombre', $this->nombre);
        $stmt->bindParam(':correo', $this->correo);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute(); 
    }
    
    public function eliminar() {
        $consulta = "DELETE FROM " . $this->tabla . " WHERE id = :id";
        $stmt = $this->conexion->prepare($consulta);

        $stmt->bindParam(':id', $this->id);

        return $stmt->execute(); 
    }
}
